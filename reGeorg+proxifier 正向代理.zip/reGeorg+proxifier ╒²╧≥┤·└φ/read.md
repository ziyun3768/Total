## reGeorg+proxifier 正向代理

reGeorg是reDuh的继承者，利用了会话层的socks5协议，效率更高一些。这也是平时用的比较多的工具。

先将reGeorg的对应脚本上传到服务器端，直接访问显示“Georg says, 'All seems fine'”，表示脚本运行正常

![img](https://static.zhishibox.net/20210115/104536821.png)

运行python reGeorgSocksProxy.py -p 8888 -u http://www.xxx.com/tunnel.php

![img](https://static.zhishibox.net/20210115/105731503.png)

将proxifier打开，在Proxy Server中这样配置

![img](https://static.zhishibox.net/20210115/102470826.png)

![img](https://static.zhishibox.net/20210115/107077165.png)

然后就可以在本地访问内网的机器了

成功3389到内网机器

![img](https://static.zhishibox.net/20210115/105080285.png)