##  LCX转发

内网机器上执行：**lcx.exe –slave** 公网IP +端口 内网IP +端口

```
例如：lcx.exe –slave 192.168.43.142 51 192.168.43.137 3389
```

将内网(192.168.43.137)的3389端口转发到公网(192.168.43.142)的51端口

![img](https://static.zhishibox.net/20210115/105459912.png)

然后在公网的机器上：

Lcx.exe –listen 监听51端口，转发到公网机器的3389端口

例如：Lcx.exe –listen 51 3389

![img](https://static.zhishibox.net/20210115/109325747.png)

这个时候已经将内网的3389转发到了公网机器的3389端口，我们在本地机器上远程公网IP+3389 ，就连接上了内网机器的3389

![img](https://static.zhishibox.net/20210115/104141205.png)