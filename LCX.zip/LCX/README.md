#  Lcx, port mapper

###  Avaliable in Windows / Linux / Mac / Android ....

use gcc/make

### Build

```
 make
```

or

```
 make command
```
for command mode.

### Hide author

```
ANONYMOUS=1 make
ANONYMOUS=1 make command
```

### Platform: windows

```
set PLATFORM=windows
```
and build
