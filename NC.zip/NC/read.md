## NC 反弹CMDshell

本机：192.168.43.142(win7) 远程机器：192.168.43.137(xp)

正向连接：

在远程机器上(t参数可以省略)

![img](https://static.zhishibox.net/20210115/107189582.png)

在本地机器上

![img](https://static.zhishibox.net/20210115/105064373.png)

成功之后，本地机器就获得了一个远程机器的shell

![img](https://static.zhishibox.net/20210115/103890707.png)

反向连接：

在本机运行上

![img](https://static.zhishibox.net/20210115/105883485.png)

在远程机器上(t参数可以省略)

![img](https://static.zhishibox.net/20210115/100470837.png)

然后成功之后，我们在本地机器上看一下，已经获得了远程机器的cmdshell

![img](https://static.zhishibox.net/20210115/108997176.png)

这里还有前人总结的十种反弹shell的方法，很不错

：http://zone.wooyun.org/content/5064 (wb%3E5)

：http://www.waitalone.cn/linux-shell-rebound-under-way.html